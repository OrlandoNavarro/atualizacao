
# Roteirizador Inteligente
Sistema completo com FastAPI (backend) + React (frontend) + Docker + Nginx

## Como rodar no seu servidor Ubuntu:
```bash
chmod +x setup.sh
./setup.sh
```
Acesse via: http://<SEU_IP>:80
