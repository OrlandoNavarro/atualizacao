
#!/bin/bash
sudo apt update && sudo apt install -y docker.io docker-compose nginx
sudo systemctl start docker
sudo docker-compose up --build -d
